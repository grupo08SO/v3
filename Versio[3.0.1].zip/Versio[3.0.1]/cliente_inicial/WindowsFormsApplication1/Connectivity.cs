﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Windows.Forms;
using WindowsFormsApplication1;

namespace WindowsFormsApplication1
{
    class Connectivity
    {
        Socket Servidor;
        IPAddress direc;
        IPEndPoint ipep;
        int PORT = 9104;

        public Socket ReturnServidor()
        {
            return Servidor;
        }

        private void SetConnection()
        {
            this.direc = IPAddress.Parse("192.168.56.104"); //IP
            this.ipep = new IPEndPoint(direc, PORT);//IP, Puerto definido como variable del Connectivity
        }

        public int ConnectServer()
        {
            this.SetConnection(); //Creamos las connexiones
            Servidor = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                this.Servidor.Connect(ipep); //Creamos una conexion con el servidor.
                return 1; //Retornamos 1 para informar al cliente de que se ha establecido connexión.
            }
            catch (SocketException)
            {
                return 0; //Retornamos 0 para informar que no se ha podido establecer connexión con el cliente.
            }
        }

        public void DisconnectServer()
        {
            //Desconectamos del servidor.
            Servidor.Shutdown(SocketShutdown.Both);
            Servidor.Close();
        }

        public void SendToServer(int codigo, string mensaje)
        {
            mensaje = codigo.ToString() + "/" + mensaje;

            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            Servidor.Send(msg); //Enviamos el mensaje
        }
         







    }
}
